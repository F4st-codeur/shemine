package fr.schemmine;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import java.io.File;
import java.io.IOException;

/** Lit les dimensions d'un .schem (Sponge v2/v3), .schematic (MCEdit) ou .litematic. */
public final class SchematicReader {
    public record Size(int x, int y, int z) {
        public long volume() { return (long) x * y * z; }
    }

    public static Size read(File f) throws IOException {
        NbtCompound root = NbtIo.readCompressed(f);
        if (f.getName().toLowerCase().endsWith(".litematic")) return litematic(root);
        if (root.contains("Schematic", 10)) root = root.getCompound("Schematic"); // Sponge v3
        int w = root.getShort("Width") & 0xFFFF;
        int h = root.getShort("Height") & 0xFFFF;
        int l = root.getShort("Length") & 0xFFFF;
        if (w == 0 || h == 0 || l == 0) throw new IOException("Dimensions introuvables dans le fichier");
        return new Size(w, h, l);
    }

    private static Size litematic(NbtCompound root) throws IOException {
        NbtCompound regions = root.getCompound("Regions");
        int[] min = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] max = {Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
        for (String key : regions.getKeys()) {
            NbtCompound r = regions.getCompound(key);
            NbtCompound p = r.getCompound("Position"), s = r.getCompound("Size");
            String[] axes = {"x", "y", "z"};
            for (int i = 0; i < 3; i++) {
                int a = p.getInt(axes[i]), sz = s.getInt(axes[i]);
                int b = a + sz - (sz > 0 ? 1 : -1);
                min[i] = Math.min(min[i], Math.min(a, b));
                max[i] = Math.max(max[i], Math.max(a, b));
            }
        }
        if (min[0] == Integer.MAX_VALUE) throw new IOException("Aucune région dans le litematic");
        return new Size(max[0] - min[0] + 1, max[1] - min[1] + 1, max[2] - min[2] + 1);
    }
}
