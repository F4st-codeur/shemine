package fr.schemmine;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.io.File;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Mod 100% client : casse les blocs de la zone du schematic, TOIT D'ABORD.
 * Seuls les blocs à portée sont minés ; s'il n'y en a pas, le mod indique où aller.
 */
public class SchemMineClient implements ClientModInitializer {
    private static SchematicReader.Size size;
    private static String loadedName = "";
    private static BlockPos origin;
    private static boolean running = false;
    private static int topY;          // couche la plus haute qui contient encore des blocs
    private static long mined = 0;
    private static int window = 4;    // on ne descend pas plus de N couches sous le toit restant
    private static BlockPos target;   // bloc en cours de minage

    private static File dir() {
        File d = FabricLoader.getInstance().getGameDir().resolve("schematics").toFile();
        d.mkdirs();
        return d;
    }

    /** Liste récursive, comme le dossier schematics de Litematica. */
    private static java.util.List<String> scan() {
        java.util.List<String> out = new java.util.ArrayList<>();
        java.nio.file.Path root = dir().toPath();
        try (var st = java.nio.file.Files.walk(root)) {
            st.filter(java.nio.file.Files::isRegularFile)
              .filter(x -> x.getFileName().toString().matches("(?i).*\\.(schem|schematic|litematic)"))
              .forEach(x -> out.add(root.relativize(x).toString().replace('\\', '/')));
        } catch (java.io.IOException ignored) {}
        java.util.Collections.sort(out);
        return out;
    }

    private static void say(FabricClientCommandSource s, String msg) {
        s.sendFeedback(Text.literal("§6[SchemMine] §r" + msg));
    }

    private static BlockPos max() { return origin.add(size.x() - 1, size.y() - 1, size.z() - 1); }

    private static boolean mineable(ClientWorld w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        return !s.isAir() && !(s.getBlock() instanceof FluidBlock) && s.getHardness(w, p) >= 0;
    }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(SchemMineClient::tick);

        ClientCommandRegistrationCallback.EVENT.register((d, reg) -> d.register(literal("schemmine")
            .then(literal("list").executes(c -> {
                java.util.List<String> f = scan();
                say(c.getSource(), f.isEmpty() ? "Aucun fichier dans " + dir() : String.join(", ", f));
                return 1;
            }))
            .then(literal("load").then(argument("fichier", StringArgumentType.greedyString()).executes(c -> {
                String name = StringArgumentType.getString(c, "fichier");
                File f = new File(dir(), name);
                if (!f.isFile()) { // cherche aussi dans les sous-dossiers, avec ou sans extension
                    for (String rel : scan()) {
                        String base = rel.substring(rel.lastIndexOf('/') + 1);
                        if (base.equalsIgnoreCase(name) || base.replaceFirst("\\.[^.]+$", "").equalsIgnoreCase(name)) {
                            f = new File(dir(), rel); break;
                        }
                    }
                }
                try {
                    if (!f.getCanonicalPath().startsWith(dir().getCanonicalPath()) || !f.isFile()) {
                        say(c.getSource(), "§cFichier introuvable dans " + dir()); return 0;
                    }
                    size = SchematicReader.read(f); loadedName = name;
                    say(c.getSource(), "Chargé §e" + name + "§r : " + size.x() + "×" + size.y() + "×" + size.z());
                    return 1;
                } catch (Exception e) {
                    say(c.getSource(), "§cErreur de lecture : " + e.getMessage()); return 0;
                }
            })))
            .then(literal("origin")
                .then(literal("here").executes(c -> {
                    origin = c.getSource().getPlayer().getBlockPos();
                    say(c.getSource(), "Coin minimum (X/Y/Z les plus bas) : " + origin.toShortString()); return 1;
                }))
                .then(argument("x", IntegerArgumentType.integer())
                    .then(argument("y", IntegerArgumentType.integer())
                        .then(argument("z", IntegerArgumentType.integer()).executes(c -> {
                            origin = new BlockPos(IntegerArgumentType.getInteger(c, "x"),
                                IntegerArgumentType.getInteger(c, "y"), IntegerArgumentType.getInteger(c, "z"));
                            say(c.getSource(), "Coin minimum : " + origin.toShortString()); return 1;
                        })))))
            .then(literal("window").then(argument("couches", IntegerArgumentType.integer(0, 10)).executes(c -> {
                window = IntegerArgumentType.getInteger(c, "couches");
                say(c.getSource(), "Fenêtre : " + window + " couches sous le toit restant"); return 1;
            })))
            .then(literal("start").executes(c -> {
                if (size == null) { say(c.getSource(), "§cFais d'abord /schemmine load <fichier>"); return 0; }
                if (origin == null) { say(c.getSource(), "§cFais d'abord /schemmine origin here"); return 0; }
                topY = max().getY(); mined = 0; target = null; running = true;
                say(c.getSource(), "Minage lancé du toit (Y=" + topY + ") vers le bas : "
                    + origin.toShortString() + " → " + max().toShortString());
                return 1;
            }))
            .then(literal("stop").executes(c -> { stop(); say(c.getSource(), "Arrêté (" + mined + " blocs)"); return 1; }))
            .then(literal("status").executes(c -> {
                say(c.getSource(), running ? "Toit restant Y=" + topY + ", " + mined + " blocs minés" : "Inactif");
                return 1;
            }))
        ));
    }

    private static void stop() {
        running = false; target = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
    }

    private static void tick(MinecraftClient mc) {
        if (!running) return;
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (player == null || world == null || im == null) { running = false; return; }
        if (mc.currentScreen != null) return;

        // 1) Faire descendre le "toit" tant que sa couche est vide (sans jamais conclure sur un chunk non chargé)
        int guard = 0;
        while (guard++ < 2 && topY >= origin.getY()) {
            boolean any = false, unknown = false;
            for (int x = origin.getX(); x < origin.getX() + size.x() && !any; x++)
                for (int z = origin.getZ(); z < origin.getZ() + size.z(); z++) {
                    BlockPos p = new BlockPos(x, topY, z);
                    if (!world.isChunkLoaded(p)) { unknown = true; continue; }
                    if (mineable(world, p)) { any = true; break; }
                }
            if (any || unknown) break;
            topY--;
        }
        if (topY < origin.getY()) {
            player.sendMessage(Text.literal("§a[SchemMine] Terminé : " + mined + " blocs minés"), false);
            stop(); return;
        }

        // 2) Cible actuelle encore valide ?
        double reach = Math.max(im.getReachDistance() - 0.4, 2.0);
        Vec3d eye = player.getEyePos();
        if (target != null && (!mineable(world, target) || Vec3d.ofCenter(target).squaredDistanceTo(eye) > reach * reach)) {
            if (!mineable(world, target)) mined++;
            target = null;
        }

        // 3) Choisir le bloc le plus HAUT à portée, dans la fenêtre sous le toit restant
        if (target == null) {
            int r = (int) Math.ceil(reach);
            BlockPos base = player.getBlockPos();
            int minY = Math.max(origin.getY(), topY - window);
            double best = Double.MAX_VALUE; int bestY = Integer.MIN_VALUE;
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = -r; dy <= r + 1; dy++) {
                BlockPos p = base.add(dx, dy, dz);
                if (p.getX() < origin.getX() || p.getX() > max().getX() || p.getZ() < origin.getZ()
                    || p.getZ() > max().getZ() || p.getY() < minY || p.getY() > topY) continue;
                double dist = Vec3d.ofCenter(p).squaredDistanceTo(eye);
                if (dist > reach * reach || !mineable(world, p)) continue;
                if (p.getY() > bestY || (p.getY() == bestY && dist < best)) { bestY = p.getY(); best = dist; target = p; }
            }
        }

        // 4) Rien à portée : dire où aller (le toit restant)
        if (target == null) {
            BlockPos near = null; double bd = Double.MAX_VALUE;
            for (int x = origin.getX(); x < origin.getX() + size.x(); x++)
                for (int z = origin.getZ(); z < origin.getZ() + size.z(); z++) {
                    BlockPos p = new BlockPos(x, topY, z);
                    if (!world.isChunkLoaded(p) || !mineable(world, p)) continue;
                    double dd = Vec3d.ofCenter(p).squaredDistanceTo(eye);
                    if (dd < bd) { bd = dd; near = p; }
                }
            im.cancelBlockBreaking();
            player.sendMessage(Text.literal(near == null
                ? "§e[SchemMine] Chunks du toit non chargés, rapproche-toi de la zone"
                : "§e[SchemMine] Monte au toit : va vers " + near.toShortString() + " (Y=" + topY + ")"), true);
            return;
        }

        // 5) Meilleur outil de la hotbar puis minage
        BlockState st = world.getBlockState(target);
        int bestSlot = player.getInventory().selectedSlot; float bestSpeed = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = player.getInventory().getStack(i);
            float sp = s.getMiningSpeedMultiplier(st);
            if (sp > bestSpeed) { bestSpeed = sp; bestSlot = i; }
        }
        player.getInventory().selectedSlot = bestSlot;

        Vec3d c = Vec3d.ofCenter(target);
        Direction face = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        if (im.updateBlockBreakingProgress(target, face)) player.swingHand(Hand.MAIN_HAND);
        player.sendMessage(Text.literal("§6[SchemMine] Toit Y=" + topY + " | " + mined + " blocs"), true);
    }
}
