# Schematic Miner - mod CLIENT (Fabric 1.20.1)
Compiler : JDK 17 + Gradle 8.5 -> `gradle build` -> build/libs/schemmine-1.0.0.jar
(ou pousse le projet sur GitHub : l'onglet Actions compile et fournit le .jar)
Installer : le .jar + Fabric API dans le dossier mods/ (solo ou serveur vanilla, rien à installer côté serveur).
Schematics : <dossier du jeu>/schematics/ (le même que Litematica, sous-dossiers inclus)

/schemmine list | load <fichier> | origin here | origin <x y z> | window <n> | start | stop | status
